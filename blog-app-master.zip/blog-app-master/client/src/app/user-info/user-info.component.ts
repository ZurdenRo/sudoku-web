import { Component, OnInit, Input } from '@angular/core';

import { UserInfoService } from './user-info.service';
import { PostsService } from '../service/posts.service';

@Component({
  selector: 'app-user-info',
  templateUrl: './user-info.component.html',
  styleUrls: ['./user-info.component.css'],
  providers:[UserInfoService, PostsService]
})
export class UserInfoComponent{

  constructor(private userInfoService: UserInfoService,
              private postsService: PostsService  
  ) { }

     
  public userName: any;
  public postsLength: any;
  public follows: any;
  public followers: any;
  public prevPost: any;
  @Input() post: any;

  ngOnInit() {
    this.getUserData();
    
  }

  getUserData(){
    var storage = localStorage.getItem("session");
    this.userInfoService.getUserData(storage).subscribe(result => {
      //this.userData = result["data"];
      this.userName = result["data"].userdata[0].username;
      this.postsLength = result["data"].doc.length;
      this.followers = result["data"].userdata[0].followers;
      this.follows = result["data"].userdata[0].follow;
    });
  }

 

}
