import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class UserInfoService {

  constructor(private http: HttpClient) { }

  domain: string = 'http://localhost:3000';
  storage: string = localStorage.getItem("session");

  getUserData(storage){
    return this.http.post(`${this.domain}/api/getUserData`,{
      token:storage
    })
  }
}
