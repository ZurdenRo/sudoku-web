import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { PostsService } from '../service/posts.service';
import { Post } from '../models/Post.model';
import { Router } from '@angular/router';
import * as moment from 'moment';
import 'moment/locale/es';

export interface Valoration {
  value: number;
  text: string;
}

@Component({
  selector: 'app-add-post-form',
  templateUrl: './add-post-form.component.html',
  styleUrls: ['./add-post-form.component.css'],
  providers:[PostsService]
})
export class AddPostFormComponent implements OnInit {

  constructor(private postService: PostsService, private router: Router) { }

  ngOnInit() {
  }

  public posts : any [];
  public post : Post;
  title:string;
  description:string;
  date: any;
  valoration: string;

  valorations: Valoration[] = [
    {value: 1, text: '1 punto'},
    {value: 2, text: '2 puntos'},
    {value: 3, text: '3 puntos'},
    {value: 4, text: '4 puntos'},
    {value: 5, text: '5 puntos'},
  ];

  @Output() addedPost = new EventEmitter();
 

  addPost() {
    var dateAdded = moment().format('DD/MM/YYYY');
    var storage = localStorage.getItem("session");
    const newPost:Post = {
      title : this.title,
      description:this.description,
      date: dateAdded,
      valoration: this.valoration
    }

    if(newPost.title && newPost.description && newPost.valoration){
      this.postService.addPost(newPost, storage).subscribe(res =>{
        console.log('response is ', res)
        if(!res["error"]){
          this.title = '';
          this.description = '';
          this.valoration = '';
          /*this.posts.push(res);*/
          this.addedPost.emit(res);

        }else{
          this.router.navigate(['']);
        }
        
      });
    } else {
      alert('Debe completar todos los campos para crear el post!');
    }
  }

}
