import { TestBed, inject } from '@angular/core/testing';

import { AddPostFormService } from './add-post-form.service';

describe('AddPostFormService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AddPostFormService]
    });
  });

  it('should be created', inject([AddPostFormService], (service: AddPostFormService) => {
    expect(service).toBeTruthy();
  }));
});
