import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserSearchedCardComponent } from './user-searched-card.component';

describe('UserSearchedCardComponent', () => {
  let component: UserSearchedCardComponent;
  let fixture: ComponentFixture<UserSearchedCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserSearchedCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserSearchedCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
