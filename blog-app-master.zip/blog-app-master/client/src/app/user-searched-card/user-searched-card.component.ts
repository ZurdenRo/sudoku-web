import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { User } from '../models/user.model';

@Component({
  selector: 'app-user-searched-card',
  templateUrl: './user-searched-card.component.html',
  styleUrls: ['./user-searched-card.component.css']
})
export class UserSearchedCardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    console.log(this.screen);
  }

  @Input() user : any;
  @Output() getUserProfile = new EventEmitter();

  screen = screen.width;

  getProfile(user) {
    this.getUserProfile.emit(user);
    
  }

}
