import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
 
@Injectable()
export class ShowPostService {
 
    constructor(private http: HttpClient){
 
    }
    
    domain: string = 'http://localhost:3000';
    storage: string = localStorage.getItem("session");

    getAllPost(storage){
      return this.http.post(`${this.domain}/api/getAllPost`,{
        token:storage
      })
    }
}