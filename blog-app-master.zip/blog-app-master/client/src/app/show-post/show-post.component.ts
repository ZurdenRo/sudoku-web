import { Component, OnInit, ViewChild, EventEmitter } from '@angular/core';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';

import { ShowPostService } from './show-post.service';

import { PostsService } from '../service/posts.service';
import { UsersService } from '../service/users.service';
import { Router } from '@angular/router';

import { Post } from '../models/Post.model';

import { UserInfoComponent } from "../user-info/user-info.component";
import { AddPostFormComponent } from "../add-post-form/add-post-form.component";
import { PostCardComponent } from "../post-card/post-card.component";

import * as moment from 'moment';
import 'moment/locale/es';


/*@Component({
  selector: 'app-show-post',
  templateUrl: './show-post.component.html',
  styleUrls: ['./show-post.component.css'],
  providers:[ShowPostService]
})*/

@Component({
  selector: 'app-show-post',
  templateUrl: './show-post.component.html',
  styleUrls: ['./show-post.component.css'],
  providers:[PostsService,UsersService]
})
export class ShowPostComponent implements OnInit {

  //constructor(private showPostService: ShowPostService) { }

  public posts : any [];
  public isSearchedUser: any = false;
  public post : Post;
  public users: any;
  public searchedProfileUser: any;
  public activeUserProfile: any = false;
  
  @ViewChild('userInfo') userInfo:UserInfoComponent;
  @ViewChild('addPostForm') addPostForm:AddPostFormComponent;
  @ViewChild('postCardComponent') postCardComponent:PostCardComponent;
  

  constructor(private postService: PostsService, 
              private router: Router, 
              private modalService:NgbModal,
              private usersService: UsersService ) {}

  ngOnInit() {
    this.getAllPost();

    this.addPostForm.addedPost.subscribe(
      res =>
      {
      console.log("Atributo:" + res);
      this.userInfo.postsLength++;
      }
    );
  }

  
  title:string;
  description:string;
  date: any;

  getAllPost(){
    var storage = localStorage.getItem("session");
    this.postService.getAllPost(storage).subscribe(result => {
      this.posts = result['data'];
    });
  }

  getAddedPost(post) {
    this.posts.push(post);
  }

  deleteTargetPost(id){
    for(let i = 0; i < this.posts.length; i++) {
      if(this.posts[i]._id == id) {
        this.posts.splice(i, 1);
        this.userInfo.postsLength --;
      }
    }
  }

  seePost(content){
    this.modalService.open(content);
  }

  getQueryToSearch(Query){
    this.getPostsByQuery(Query);
  }

  getPostsByQuery(params) {

    var storage = localStorage.getItem("session");
    this.postService.getPostsByQuery(params,storage).subscribe(result => {
      
      let postResult = [];
      Object.keys(result).forEach(function(key){
        postResult.push(result[key])
      })
      this.posts = postResult;
    });
  }
  
  getUserToSearch(User){
    this.getUserByQuery(User);
  }

  getUserByQuery(params){
  
    this.users = [];
    this.isSearchedUser = true;
    this.activeUserProfile = false;

    var storage = localStorage.getItem("session");
    this.usersService.getUsersByQuery(params,storage).subscribe(result => {
      
      let usersResult = [];
      result['data'].forEach(function(user){
        usersResult.push(user);
      })
      this.users = usersResult;
    });
  }

  getUserProfile(user){
    this.searchedProfileUser = user;

    console.log("usuario para perfil", user);
    var storage = localStorage.getItem("session");
    this.usersService.getUserProfile(user,storage).subscribe(result => {
      
      let postResult = [];
     
      this.searchedProfileUser.data = result['data'];
      this.activeUserProfile = true;
    });
  }


}
