import { Component, OnInit,EventEmitter, Output } from '@angular/core';


export interface Valoration {
  value: number;
  text: string;
}

@Component({
  selector: 'app-post-searcher',
  templateUrl: './post-searcher.component.html',
  styleUrls: ['./post-searcher.component.css']
})
export class PostSearcherComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  @Output() query = new EventEmitter<any>();

  titulo:string;
  selected:any;

  valorations: Valoration[] = [
    {value: 1, text: '1 punto'},
    {value: 2, text: '2 puntos'},
    {value: 3, text: '3 puntos'},
    {value: 4, text: '4 puntos'},
    {value: 5, text: '5 puntos'},
  ];


  searchPost() {
    this.query.emit(this.prepareRequest());
  }

  private prepareRequest(): any {
    console.log(this.selected)
    let query = {
      title:this.titulo || "",
      valoration: parseInt(this.selected) || 0
    }
    return query;
  }

}
