import { RouterModule, Routes } from '@angular/router';
import { ModuleWithProviders } from '@angular/core/src/metadata/ng_module';
 
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { ErrorPageComponent } from './error-page/error-page.component';
import { LogoutComponent } from './logout/logout.component';
import { CreateUserComponent } from './create-user/create-user.component'
 
export const AppRoutes: Routes = [
    { path: '', component: LoginComponent },
    { path: 'home', component: HomeComponent },
    { path: 'error/:message', component: ErrorPageComponent },
    { path: 'logout', component: LogoutComponent },
    { path: 'createUser', component: CreateUserComponent }

];
 
export const ROUTING: ModuleWithProviders = RouterModule.forRoot(AppRoutes);