import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Post } from '../models/Post.model';
 
@Injectable()
export class UsersService {
 
    constructor(private http: HttpClient){
    }

    public data = {};
    domain: string = 'http://localhost:3000';
    storage: string = localStorage.getItem("session");

    
    getUsersByQuery(query,storage){
        return this.http.post(`${this.domain}/api/getUsersByQuery`,{
            token:storage,
            query: query
        })
    }

    getUserProfile(user,storage){
        return this.http.post(`${this.domain}/api/getUserProfileData`,{
            token:storage,
            user: user
        })
    }

    saveUser(user, storage){
        return this.http.post(`${this.domain}/api/saveUser`,{
            token:storage,
            user: user
        })
    }

}