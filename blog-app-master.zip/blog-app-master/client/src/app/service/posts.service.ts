import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Post } from '../models/Post.model';
 
@Injectable()
export class PostsService {
 
    constructor(private http: HttpClient){
    }

    public data = {};
    domain: string = 'http://localhost:3000';
    storage: string = localStorage.getItem("session");

    getAllPost(storage){
      return this.http.post(`${this.domain}/api/getAllPost`,{
          token:storage
      })
    }

    addPost(post: Post, storage){
        return this.http.post(`${this.domain}/api/createPost`,{
            title : post.title,
            description : post.description,
            token: storage,
            date: post.date,
            valoration: post.valoration
        })
    }

    deletePost(id, storage) {
        return this.http.delete(`${this.domain}/api/deletePost/${id}/${storage}`)
    }

    getPostsByQuery(query,storage){
        return this.http.post(`${this.domain}/api/getPostsByQuery`,{
            token:storage,
            query: query
        })
    }

}