import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

import {PostsService} from '../service/posts.service'

@Component({
  selector: 'app-post-card',
  templateUrl: './post-card.component.html',
  styleUrls: ['./post-card.component.css'],
  providers: [PostsService]
})
export class PostCardComponent{

  @Input() post: any;
  @Output() deletedPostId = new EventEmitter();

  numberReturn(length){
    var arr = new Array(parseInt(length))
    arr.forEach(function(elem, idx, arr){
      arr.push(1);
    })
    return arr;
  }

  constructor(private postService: PostsService) { }

  deletePost(id) {
    const response = confirm('¿esta seguro que desea eliminar este cliente?');
    if (response ){
      const post = this.post;
      var storage = localStorage.getItem("session");
      this.postService.deletePost(id, storage)
        .subscribe(data => {
          console.log(data);
          this.deletedPostId.emit(id);
          
        })
    }
  }

}
