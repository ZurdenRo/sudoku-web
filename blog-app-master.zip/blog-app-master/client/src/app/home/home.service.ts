import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../models/user.model';


@Injectable()
export class HomeService {

  constructor(private http: HttpClient){
    
  }
  storage: string = localStorage.getItem("session");
  domain: string = 'http://localhost:3000';

  isSessionActive(storage){
    return this.http.post(`${this.domain}/api/isSessionActive`,{
        token: storage
    });
  }
}
