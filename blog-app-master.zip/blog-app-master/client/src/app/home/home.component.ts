import { Component } from '@angular/core';
import { HomeService } from './home.service';
import { User } from '../models/user.model';


import { Router } from '@angular/router';
 
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  providers:[HomeService]
})
export class HomeComponent {

  constructor(private homeService: HomeService, private router: Router ) {
    /*this.user = new User();
    this.isSessionStart();*/
    this.isSessionActive();
  }

  isSessionActive(){
    var storage = localStorage.getItem("session");
  
    this.homeService.isSessionActive(storage).subscribe(result => {
        if(result['status'] == "success" ) {
          console.log(result)
        }
        if(result['status'] == "fail" ) {
          console.log(result);
          localStorage.setItem("session","");
          this.router.navigate(['error']);
        } 
    }, error => {
      console.log('error is ', error);
      this.router.navigate(['']);
    });

  }

  logout(){
    if(typeof localStorage.getItem("session") != "undefined"){

      var storage = localStorage.getItem("session");

      this.homeService.isSessionActive(storage).subscribe(result => {
          if(result['status'] == "success" ) {
            localStorage.setItem("session","");
            var message = "closed";
            this.router.navigate(['']);
            console.log("sesion cerrada correctamente");
          }
          if(result['status'] == "fail" ) {
            console.log("error al controlar la sesion antes de cerrar");
            localStorage.setItem("session","");
            this.router.navigate(['error']);
          } 
      }, error => {
        console.log('error is ', error);
        this.router.navigate(['error']);
      });
    }
    
  }
   
}