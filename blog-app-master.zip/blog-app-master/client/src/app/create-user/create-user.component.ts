import { Component, OnInit } from '@angular/core';
import {FormControl, FormGroupDirective, NgForm, Validators, FormGroup, AbstractControl, ValidatorFn} from '@angular/forms';
import {ErrorStateMatcher} from '@angular/material/core';
import {UsersService} from '../service/users.service';
import { Router } from '@angular/router';

export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

export function isAvailableUser(username: string): ValidatorFn {
  return (control: AbstractControl): {[key: string]: any} | null => {
    let forbidden = false;
    if(username === "hola") forbidden = true;
    return forbidden ? {'forbiddenName': {value: control.value}} : null;
  };
}

@Component({
  selector: 'app-create-user',
  templateUrl: './create-user.component.html',
  styleUrls: ['./create-user.component.css'],
  providers:[UsersService]
})
export class CreateUserComponent {

  constructor(private userService :  UsersService, private router : Router) { }

  ngOnInit() {
  }
  
  public error = true;
  public isAvailableUser = true;
  public isRegisteredMail = false;


  usernameFormControl= new FormControl('',[
    Validators.required,
  ]);

  emailFormControl= new FormControl('', [
      Validators.required,
      Validators.email,
  ]);
  passwordFormControl= new FormControl('');

  matcher = new MyErrorStateMatcher();

  createUser(){
    
    if(this.usernameFormControl.value != "" && this.emailFormControl.value != "" && this.passwordFormControl.value != ""){
      var storage = localStorage.getItem("session");
      let newUser = {
        username: this.usernameFormControl.value,
        email: this.emailFormControl.value,
        password: this.passwordFormControl.value,
        follow: "0",
        followers: "0"
      }

      this.userService.saveUser(newUser, storage).subscribe(res =>{
        console.log('response is ', res)

        if(res['data'].length == 0){
          this.router.navigate(['']);

        }else{
          if(res['data']['username']){
            this.usernameFormControl.setValue('');
            this.isAvailableUser = false;
          }
          if(res['data']['email']){
            this.emailFormControl.setValue('');
            this.isRegisteredMail = true;
          }
        }
        /*if(!res["error"]){
         
          this.router.navigate(['']);
        }else{
          //this.router.navigate(['']);
        }*/
        
      });
    }
  }
 
}
