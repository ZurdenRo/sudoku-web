import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-searched-user-profile-card',
  templateUrl: './searched-user-profile-card.component.html',
  styleUrls: ['./searched-user-profile-card.component.css']
})
export class SearchedUserProfileCardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  @Input() userProfileData: any;

}
