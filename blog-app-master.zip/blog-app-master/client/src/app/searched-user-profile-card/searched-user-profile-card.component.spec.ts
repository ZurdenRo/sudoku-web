import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchedUserProfileCardComponent } from './searched-user-profile-card.component';

describe('SearchedUserProfileCardComponent', () => {
  let component: SearchedUserProfileCardComponent;
  let fixture: ComponentFixture<SearchedUserProfileCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchedUserProfileCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchedUserProfileCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
