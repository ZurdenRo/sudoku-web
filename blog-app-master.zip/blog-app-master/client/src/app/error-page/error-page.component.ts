import { Component, OnInit } from '@angular/core';
import { ErrorPageService } from './error-page.service';
import { User } from '../models/user.model';

import { Router, ActivatedRoute, ActivatedRouteSnapshot } from '@angular/router';


@Component({
  selector: 'app-error-page',
  templateUrl: './error-page.component.html',
  styleUrls: ['./error-page.component.css'],
  providers:[ErrorPageService]
})
export class ErrorPageComponent{

  constructor(private homeService: ErrorPageService, private router: Router, private activatedRoute: ActivatedRoute) {
    
  }
  public message : string;

  ngOnInit() {
    // subscripción al observable params
    /*this.activatedRoute.params
      .subscribe(params => {
        const message = params['message'].toString();
        console.log("mensaje", message);
      });*/
      this.message = this.activatedRoute.snapshot.params.message;
      var mensaje = this.activatedRoute.snapshot.params.message;
      console.log("mensaje actual", mensaje);
  }

  loginRedirect(){
    
    this.router.navigate(['']);
  }
  

}
