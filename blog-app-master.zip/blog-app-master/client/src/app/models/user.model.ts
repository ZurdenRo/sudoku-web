export class User {
    constructor(){
        this.username = '';
        this.password = '';
    }
    public username;
    public password;
}