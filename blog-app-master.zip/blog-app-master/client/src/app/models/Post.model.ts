export class Post {
    /*constructor(){
        this.title = '';
        this.description = '';
    }
    public title;
    public description;*/
    id?:string;
    title:string;
    description:string;
    date: any;
    valoration: any;
}