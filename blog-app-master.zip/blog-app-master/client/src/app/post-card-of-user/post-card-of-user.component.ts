import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-post-card-of-user',
  templateUrl: './post-card-of-user.component.html',
  styleUrls: ['./post-card-of-user.component.css']
})
export class PostCardOfUserComponent {

  @Input() post: any;
  @Output() deletedPostId = new EventEmitter();

  numberReturn(length){
    var arr = new Array(parseInt(length))
    arr.forEach(function(elem, idx, arr){
      arr.push(1);
    })
    return arr;
  }

  constructor() { }

  

}
