import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { MaterialModule } from './material-module';
import 'hammerjs';

import {ReactiveFormsModule} from '@angular/forms';
import {FormControl, FormGroupDirective, NgForm, Validators, FormGroup} from '@angular/forms';

import { RootComponent } from './root/root.component';

import { ROUTING } from './app.routing';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { ShowPostComponent } from './show-post/show-post.component';
import { ErrorPageComponent } from './error-page/error-page.component';
import { UserInfoComponent } from './user-info/user-info.component';
import { PostCardComponent } from './post-card/post-card.component';
import { PostSearcherComponent } from './post-searcher/post-searcher.component';
import { AddPostFormComponent } from './add-post-form/add-post-form.component';
import { UserSearchComponent } from './user-search/user-search.component';
import { UserSearchedCardComponent } from './user-searched-card/user-searched-card.component';
import { ErrorCardComponent } from './error-card/error-card.component';
import { SearchedUserProfileCardComponent } from './searched-user-profile-card/searched-user-profile-card.component';
import { PostCardOfUserComponent } from './post-card-of-user/post-card-of-user.component';
import { LogoutComponent } from './logout/logout.component';
import { CreateUserComponent } from './create-user/create-user.component';



@NgModule({
  declarations: [
  
    RootComponent,
    HomeComponent,
    LoginComponent,
    ShowPostComponent,
    ErrorPageComponent,
    UserInfoComponent,
    PostCardComponent,
    PostSearcherComponent,
    AddPostFormComponent,
    UserSearchComponent,
    UserSearchedCardComponent,
    ErrorCardComponent,
    SearchedUserProfileCardComponent,
    PostCardOfUserComponent,
    LogoutComponent,
    CreateUserComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    ROUTING,
    FormsModule,
    NgbModule.forRoot(),
    BrowserAnimationsModule,
    MaterialModule,
   
    ReactiveFormsModule,
  ],
  providers: [],
  bootstrap: [RootComponent]
})
export class AppModule { }
