const router = require('express-promise-router')();
const mongojs = require('mongojs');
const dbUsers = mongojs('local', ['users']);
const dbPosts = mongojs('test', ['posts']);
const sessionController = require("../middlewares/session");
const fn = require("../common/function");
var jwt = require('jsonwebtoken');

router.post('/getUserData', (req, res) => {
    let returnObj = []
    const token = req.body.token;
    
    var sessionControlerResponse = sessionController.isSecureConection(token);
    if(sessionControlerResponse === "Ok"){
        var decoded = sessionController.decodeToken(token);

        dbPosts.post.find({username:decoded.username},[],{ sort: { _id: -1 } },(err, doc) => {
            if(err) throw err;

            dbUsers.users.find({username:decoded.username},function(err, userdata){
                if(err) throw err;
               
                return res.status(200).json({
                    status: 'success',
                    data: {userdata:userdata, doc:doc}
                })
            });
            
        });

        
    }else{

        return res.status(200).json({
            status: 'fail',
            message: 'Conexion Rechazada',
            conectionStatus: "Error"
        });

    }
})

router.post('/getUsersByQuery', (req, res) => {
    
    var query = req.body.query;
    var token = req.body.token;

    var sessionControlerResponse = sessionController.isSecureConection(token);
    if(sessionControlerResponse === 'Ok'){
        
        var decoded = sessionController.decodeToken(token);
        
        let controledQuery = fn.controlQueryParams(query);
        let queryToSearch = fn.prepareQueryToSearch(controledQuery, decoded["username"], false);
        console.log("query", queryToSearch)
        dbUsers.users.find(queryToSearch, (err, userData) => {
            
            let returnObj = fn.controlReturnObj(userData);
            console.log('return data', returnObj)
            if(err){ res.json({error:"ocurrio un problema al buscar el usuario"}); }

            return res.status(200).json({
                status: 'success',
                data: returnObj
            })
        });
    }else{
        res.json({error: "fail Conection"});
    }
})

router.post('/getUserProfileData', (req, res) => {
    let returnObj = []
    const user = req.body.user;
    const token = req.body.token;
    
    var sessionControlerResponse = sessionController.isSecureConection(token);
    if(sessionControlerResponse === "Ok"){
        var decoded = sessionController.decodeToken(token);

        dbPosts.post.find({username:user.username},[],{ sort: { _id: -1 } },(err, doc) => {
            if(err) throw err;
               
            return res.status(200).json({
                status: 'success',
                data: doc
            })
            
            
        });

        
    }else{

        return res.status(200).json({
            status: 'fail',
            message: 'Conexion Rechazada',
            conectionStatus: "Error"
        });

    }
})


router.post('/saveUser', (req, res) => {
    let returnObj = []
    const user = req.body.user;

    dbUsers.users.find({username:user.username},function(err, userdata){
        if(err) throw err;
        
        console.log("find username", userdata[0])
        if(typeof userdata[0] != "undefined" && userdata[0]['username'] == user.username){
            
            return res.status(200).json({
                status: 'success',
                data: {"username": userdata[0].username}
            });

        }else{

            dbUsers.users.find({email:user.email},function(err, userdata){
                if(err) throw err;
                
                if(typeof userdata[0] != "undefined" &&  userdata[0]['email'] === user.email){

                    return res.status(200).json({
                        status: 'success',
                        data: {"email": userdata[0].email}
                    });

                }else{
                    dbUsers.users.save(user, (err, user) => {
                        if (err) return next(err);

                        return res.status(200).json({ 
                            status: 'success',
                            data: []
                        });
                    });
                   
                }
                
            });
        }      
            
    });
   
})

module.exports = router;