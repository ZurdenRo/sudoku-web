const router = require('express-promise-router')();
const mongojs = require('mongojs');
const sessionController = require("../middlewares/session");
const db = mongojs('local', ['users']);


router.post('/login', (req, res) => {

    const reqUser = req.body;
    console.log(reqUser)
    db.users.find({
        username : reqUser.username, password : reqUser.password
    }, function(err, user){
        if(err) throw err;
        if(user.length === 1){  
            req.session.user_id = user[0]._id;
            var token = sessionController.getSessionToken(reqUser.username,reqUser.password,req.session.user_id);
            return res.status(200).json({
                status: 'success',
                data: token
            })
        } else {
            return res.status(200).json({
                status: 'fail',
                message: 'Login Failed'
            });
        }
         
    })
});

router.post('/isSessionActive', (req, res) => {
    const token = req.body.token;
    var sessionControlerResponse = sessionController.isSecureConection(token);
    if(sessionControlerResponse === "Ok"){
        return res.status(200).json({
            status: 'success',
            data: token,
            conectionStatus: "Ok"
        })
    }else{
        return res.status(200).json({
            status: 'fail',
            message: 'Conexion Rechazada',
            conectionStatus: "Error"
        });
    }
    
         
})



module.exports = router;