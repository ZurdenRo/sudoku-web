const router = require('express-promise-router')();
const mongojs = require('mongojs');
const db = mongojs('test', ['users']);
const sessionController = require("../middlewares/session");
const fn = require("../common/function");
var jwt = require('jsonwebtoken');

router.post('/getAllPost', (req, res) => {
    const token = req.body.token;
   
    var sessionControlerResponse = sessionController.isSecureConection(token);
    if(sessionControlerResponse === "Ok"){
        var decoded = sessionController.decodeToken(token);

        db.post.find({username:decoded.username},[],{ sort: { _id: -1 } },(err, doc) => {
            if(err) throw err;
            return res.status(200).json({
                status: 'success',
                data: doc
            });
            
        });
    }else{
        

    }
})

router.post('/createPost', (req, res) => {
    // insert the details to MongoDB
    const post = req.body;
    console.log("add post", post)
    var sessionControlerResponse = sessionController.isSecureConection(post.token);
    if(sessionControlerResponse === "Ok"){
        if(!post.title || !post.description || !post.valoration) {
            res.status(400).json({
                'error': 'Bad Data'
            });
        } else {
            var decoded = sessionController.decodeToken(post.token);
          
            const savedPost = {
                title: post.title,
                description: post.description,
                date:post.date,
                username: decoded.username,
                valoration: post.valoration            
            }
            db.post.save(savedPost, (err, post) => {
                if (err) return next(err);
                res.json(post);
            });
        }
    }else{
        /*res.status(400).json({
            'error': 'Expiro su conexion'
        }); */
        res.json({error: "fail Conection"});
    }
    
});

router.delete('/deletePost/:id/:storage', (req, res, next) => {
    var sessionControlerResponse = sessionController.isSecureConection(req.params.storage);
    if(sessionControlerResponse === "Ok"){
        var decoded = sessionController.decodeToken(req.params.storage);
        db.post.remove({_id: mongojs.ObjectId(req.params.id), username: decoded["username"]}, (err, post) => {
            if(err){ res.send(err); }
            res.json(post);
        });
    }else{
        res.json({error: "fail Conection"});
    }
});

router.post('/getPostsByQuery', (req, res) => {
    var query = req.body.query;
    var token = req.body.token;

    var sessionControlerResponse = sessionController.isSecureConection(token);
    if(sessionControlerResponse === 'Ok'){
        console.log("decoded", req.params)
        var decoded = sessionController.decodeToken(token);
        
        let controledQuery = fn.controlQueryParams(query);
        let queryToSearch = fn.prepareQueryToSearch(controledQuery, decoded["username"], true);
        
        db.post.find(queryToSearch, (err, post) => {
            if(err){ res.send(err); }
            res.json(post);
        });
    }else{
        res.json({error: "fail Conection"});
    }
   
})


module.exports = router;