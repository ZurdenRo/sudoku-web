const router = require('express-promise-router')();
const mongojs = require('mongojs');
const db = mongojs('mean-tasks', ['clientes']);

// obtener todos los clientes
router.get('/clientes', (req, res, next) => {
    db.clientes.find((err, clientes) => {
        if (err) return next(err);
        res.json(clientes);
    });
});

//obtener un cliente en especifico
router.get('/clientes/:id', (req, res, next) => {
    db.clientes.findOne({_id: mongojs.ObjectId(req.params.id)}, (err, cliente) => {
        if (err) return next(err);
        res.json(cliente);
    });
});

//agregar un cliente
router.post('/clientes', (req, res, next) => {
    const cliente = req.body;
    if(!cliente.nombre || !cliente.apellido || !cliente.mail || !cliente.direccion) {
        res.status(400).json({
            'error': 'Bad Data'
        });
    } else {
        db.clientes.save(cliente, (err, cliente) => {
            if (err) return next(err);
            res.json(cliente);
        });
    }
});

//eliminar un cliente
router.delete('/clientes/:id', (req, res, next) => {
    db.clientes.remove({_id: mongojs.ObjectId(req.params.id)}, (err, cliente) => {
        if(err){ res.send(err); }
        res.json(cliente);
    });
})

//modificar un cliente
router.put('/clientes/:id', (req, res, next) => {
    const cliente = req.body;
    let updateCliente = {};
    
    /*if(cliente.isDone) {
        updateCliente.isDone = cliente.isDone;
    }
    if(cliente.title) {
        updateCliente.title = cliente.title;
    }*/

    updateCliente.nombre = cliente.nombre; 
    updateCliente.apellido = cliente.apellido;
    updateCliente.telefono = cliente.telefono;
    updateCliente.direccion = cliente.direccion;
    updateCliente.mail = cliente.mail;
   
    if(!updateCliente) {
        res.status(400);
        res.json({'error': 'bad request'});
    } else {
        db.clientes.update({_id: mongojs.ObjectId(req.params.id)}, updateCliente, {}, (err, cliente) => {
            if (err) return next(err);
            res.json(cliente);
        });
    }
});


module.exports = router;