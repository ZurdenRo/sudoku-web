/*module.exports = function(req, res, next){
    if(!req.session.user_id){
        console.log('redirect');
        res.redirect("/login");
    }else{
        console.log('next');
        next();
    }
}*/
var jwt = require('jsonwebtoken');

function getSessionToken(username, password, _id){
    var tokenData = {
      username: username,
      password: password,
      _id: _id
      // ANY DATA
    }
    console.log(username);
        
    var token = jwt.sign(tokenData, 'sesionInit', {
         expiresIn: 1800 // expires in 30 mins, exp in secs
    })
        
    return token;
}

function isSecureConection(jasonToken){
    var token = jasonToken.replace('Bearer ', '');
    var returned = "";

    jwt.verify(token, 'sesionInit', function(err, user) {
      if (err) {
        returned = "Invalid";
      } else {
        returned = "Ok";
      }
    });

    return returned;
}

function decodeToken(jasonToken){
    var token = jasonToken.replace('Bearer ', '');
    var decoded = jwt.verify(token, 'sesionInit');
    return decoded;
}


exports.getSessionToken = getSessionToken;
exports.isSecureConection = isSecureConection;
exports.decodeToken = decodeToken;