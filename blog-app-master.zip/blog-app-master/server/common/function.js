module.exports ={
    controlQueryParams : function(query){
        Object.keys(query).forEach(function(elem){
            if (typeof query[elem] === "undefined" || query[elem] == "")
                delete query[elem]
        })
        return query;
    },
    prepareQueryToSearch: function(query, username, withUser){
        if(withUser)
            query["username"] = username;
        Object.keys(query).forEach(function(key){
            query[key] = {$regex:".*"+ query[key] +".*"}
        })
        return query;
    },
    controlReturnObj: function(objects){
        
        let formatedArray = objects.map(function(obj){ 
            if(obj.hasOwnProperty('password'))
                delete obj['password']
            return obj;
         });

        return formatedArray;
    }
}

