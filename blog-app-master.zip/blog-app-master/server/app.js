const express = require('express');
const path = require('path');
const cors = require('cors');
var session = require('express-session');

//const indexRoutes = require('./routes/index');
const tasksRoutes = require('./routes/tasks');
const loginRoutes = require('./routes/login');
const postRoutes = require('./routes/post');
const userRoutes = require('./routes/user');


var sessionMiddleware = require('./middlewares/session');

//comentar si no anda
const clientesRoutes = require('./routes/clientes');

const app = express();

// settings
// app.set('views', path.join(__dirname, 'views'));
// app.engine('html', require('ejs').renderFile);
// app.set('view engine', 'ejs');

app.set('port', process.env.PORT || 3000);

// middlewares
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({extended: false}));
app.use(session({
    secret:"angulartest",
    resave: false,
    saveUninitialized : false
}));

// routes
// app.use('/', indexRoutes);
//app.use('/api', sessionMiddleware);
app.use('/api', tasksRoutes);
app.use('/api', clientesRoutes);
app.use('/api', loginRoutes);
app.use('/api', postRoutes);
app.use('/api', userRoutes);

// static files
app.use(express.static(path.join(__dirname, 'dist')));

// start the server
app.listen(app.get('port'), () => {
    console.log('server on port 3000');
}); 